// Legend Store - MLBB Diamond Recharge with Firebase Auth, Razorpay, and Orders
// [TRUNCATED FOR BREVITY: Assume this is the full code user provided]
